//program to print number if it is negative//

#include <iostream>

using namespace std;

int main()
{
    
int a;
    
cout<<"enter the value of a : "<<endl;
    
cin>>a;
    
if(a<0)
   
{
        
cout<<"a is negative : "<<a<<endl;
    
}
    
else
    
{
        
cout<<"a is positive";
    
}
    
return 0;

}

