/*Program to find sum of n natural numbers*/

#include <iostream>

using namespace std;

int main()
{

int a,n,sum,i;

cout <<"enter the value of n : "<<endl;

cin >>n;

sum=0;

for(i=1;i<=n;i++)

{
    
sum += i;

}

cout<<"sum of n natural numbers : "<<sum<<endl;

return 0;

}
