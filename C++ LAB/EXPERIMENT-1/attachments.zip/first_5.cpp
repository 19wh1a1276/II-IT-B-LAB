/*Program to print  1 to 5 natural numbers*/

#include <iostream>

using namespace std;

int main()
{

int i;
cout<<"FIRST FIVE NATURAL NUMBERS ARE:"<<endl;for(i=1;i<=5;i++)

{

cout<<i<<endl;

}

return 0;

}
