/*Program to print sum and average until negitive number are given*/

#include <iostream>

using namespace std;

void printnumber()
    
{
        
int i=1,sum=0,n;
        
float avg;
    
label:
        
cout<<"enter integer value"<<endl;
        
cin>>n;
        
if(n>=0)
        
{
            
sum=sum+n;
            
i++;
            
goto label;
            
        
}
        
avg=sum/i;
    
cout<<"sum and average values are : "<<sum<<","<<avg<<endl;
    
}

int main()
{

printnumber();

return 0;

}
