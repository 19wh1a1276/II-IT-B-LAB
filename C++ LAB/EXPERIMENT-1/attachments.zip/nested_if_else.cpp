/*Nested if-else condition*/

#include <iostream>

using namespace std;

int main()
{

int a;

cout <<"enter the values of a : "<<endl;

cin >>a;

if(a!=0)
{
    
if(a%2==0)
    
{
        
cout<<"a is even";
    
}
    
else
    
{
        
cout<<"a is odd";
    
}

}

else

{
    
cout<<"a is 0 , it is neither even nor odd";

}

return 0;

}
