/*logical operators*/

#include<iostream>

using namespace std;

int main(){
    
int a,b,c;
    
cout<<"enter the values of a and b : "<<endl;
    
cin>>a;
    
cin>>b;
    
c=a&&b;
    
cout<<"value of logical and is : "<<c<<endl;
    
c=a||b;
    
cout<<"value of logical or : "<<c<<endl;
    
c= !b;
    
cout<<"value of logical not : "<<c<<endl;
    
return 0;

}