/*Program to print sum of maximum 10 numbers */

#include <iostream>

using namespace std;

int main()
{

int i,n,sum;

for(i=1;i<=10;i++)

{
    
cout<<"enter integer value"<<endl;
    
cin>>n;
    
if(n>0)
    
{
        
sum = sum+n;
    
}
    
else
   
{
        
break;
    
}

}

cout<<"sum value is : "<<sum<<endl;

return 0;

}
