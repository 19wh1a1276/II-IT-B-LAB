/*incrent&decrement operators*/

#include <iostream>

using namespace std;

int main()
{
    
int a;
    
cout <<"enter the values of a"<<endl;
    
cin >>a;
    
++a;  // pre-incrementing a //
    
cout<<"after pre-incrementing the value of a : "<<a<<endl;
    
a++;  // post-incrementing a //
    
cout<<"after post-incrementing the value of a : "<<a<<endl;
    
cout <<"now the value of a is : "<<a<<endl;
    
--a; //pre-decrement a//
    
cout <<"after pre-decrementing a : "<<a<<endl;
    
a--; //post-decrement a//
    
cout <<"after post-decrementing a : "<<a<<endl;
    
return 0;

}
