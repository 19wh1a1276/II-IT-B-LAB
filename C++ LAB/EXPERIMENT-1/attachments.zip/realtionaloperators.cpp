/*Relational operators*/

#include <iostream>

using namespace std;

int main()
{

int a,b;

bool c;

cout <<"enter the values of a and b : "<<endl;

cin >>a;

cin >>b;

c=a<b; 

cout<<"a less than b : "<<c<<endl;

c=a>b;

cout<<"a greater than b : "<<c<<endl;

c=(a=b);

cout<<"a is equal to b : "<<c<<endl;

return 0;

}
