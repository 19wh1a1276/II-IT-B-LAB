/*arthematic operators*/

#include <iostream>

using namespace std;

int main()
{
    
int a,b,ADD,SUBSTRACT,MODULOUS,MULTIPLY;
    
float DIVIDE;
    
cout <<"enter the values of a and b"<<endl;
    
cin >>a;
    
cin >>b;
    
ADD=a+b;
    
SUBSTRACT=a-b;
    
MODULOUS=a%b;
    
MULTIPLY=a*b;
    
DIVIDE=a/b;
    
cout <<"results of the arthematic operators are : "<<"\n"<<"ADD: "<<ADD<<"\n"<<"SUBTRACT: "<<SUBSTRACT<<"\n"<<"MODULUS:"<<MODULOUS<<"\n"<<"MULTIPLY: "<<MULTIPLY<<"\n"<<"DIVIDE :"<<DIVIDE<<","<<endl;
    
return 0;

}
