/*Program to construct a simple calculator using switch*/

#include <iostream>

using namespace std;

int main(){
    
char arithmatic_operator;
    
float a,b;
    
cout<<"enter any arithmatic operator"<<endl;
    
cin>>arithmatic_operator;
    
cout<<"enter a and b values"<<endl;
    
cin>>a;
    
cin>>b;
cout<< "RESULT OF ARITHEMATIC OPERAION IS: ";
    
switch (arithmatic_operator)
    
{
        
case '+' :
            cout<<a+b<<endl;
            
break;
        
case '-' :
            cout<<a-b<<endl;
            
break;
        
case '*' :
            cout<<a*b<<endl;
            
break;
        
case '/' :
            cout<<a/b<<endl;
            
break;
        
default:
        cout<<"arithmatic operator not found"<<endl;
    
}
    
return 0;

}