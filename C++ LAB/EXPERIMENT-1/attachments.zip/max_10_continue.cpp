/*Program to print sum of numbers untill the userenters 0 */

#include <iostream>

using namespace std;

int main()
{

int i,n,sum;

for(i=1;i<=10;i++)

{
    
cout<<"enter integer value"<<endl;
    
cin>>n;
    
if(n>0)
    
{
        
sum = sum+n;
    
}
    
else
    
{
        
continue;
    
}

}

cout<<"sum value is : "<<sum<<endl;

return 0;

}
