/*Program to print sum of numbers untill the user enters 0 */

#include <iostream>

using namespace std;

int main()
{

int n,sum;

sum=0;

do
{
    
cout<<"enter any integer : "<<endl;
    
cin>>n;
    
sum=sum+n;

}

while(n>0);

cout<<"addition of given numbers is : "<<sum<<endl;

return 0;

}
