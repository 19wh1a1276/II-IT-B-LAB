/*Assignment operators*/


#include <iostream>


using namespace std;


int main()
{
    

int a,b;
    

cout <<"enter the values of a and b: "<<endl;


cin >>a;
    

cin >>b;
    

a += b; 
    

cout<<"value of a += b : "<<a<<endl;
    

a -= b;
    

cout<<"value of a -= b : "<<a<<endl;
    

a *= b;
    

cout<<"value of  a *= b: "<<a<<endl;
    

a /= b;
    

cout <<"value of a /= b : "<<a<<endl;
    

return 0;


}
